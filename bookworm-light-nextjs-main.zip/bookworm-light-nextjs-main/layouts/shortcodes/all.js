import Button from "./Button";
const shortcodes = {
  Button,
};

export { Button, shortcodes };
